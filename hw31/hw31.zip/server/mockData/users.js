export const usersMock = [
  {
    id: 'u1',
    login: 'admin',
    email: 'admin@mail.com',
    password: '12345', 
    name: 'Admin',
  },
  {
    id: 'u2',
    login: 'olha',
    email: 'olha@mail.com',
    password: 'qwerty',
    name: 'Olha',
  },
];
