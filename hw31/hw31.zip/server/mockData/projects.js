export const projectsMock = [
  {
    id: '1',
    title: 'Module 1',
    priority: 'HIGH',
    description: 'Lorem Ipsum lala lala lalalal'
  },
  {
    id: '2',
    title: 'Module 2',
    priority: 'MEDIUM',
    description: 'Lorem Ipsum lala lala lalalal'
  },
  {
    id: '3',
    title: 'Module 3',
    priority: 'LOW',
    description: 'Lorem Ipsum lala lala lalalal'
  },
];